<?php

	$text = isset($_POST['input'])? strip_tags($_POST['input']): '';
	$style = isset($_POST['style'])? intval($_POST['style']): 0;
	$layout = isset($_POST['layout'])? intval($_POST['layout']): 0;
	$padding = isset($_POST['padding'])? intval($_POST['padding']): 0;
	$separator = isset($_POST['separator'])? substr($_POST['separator'], 0, 1): ';';

	require_once "BoxChars.php";
	$box = new BoxChars();
	$box->setText($text);
	$box->setStyle($style);
	$box->setLayout($layout);
	$box->setPadding($padding);
	$box->setSeparator($separator);

?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Result</title>
</head>
<body>
<h1>Result</h1>
<p>
	style=<?php echo $box->getStyle() ?>
	layout=<?php echo $box->getLayout() ?>
	padding=<?php echo $box->getPadding() ?>
	separator=<?php echo $box->getSeparator() ?>
</p>
<pre><code><?php
	//print_r($box);
	//var_dump($box->tabulate());
	echo $box->text();
?></code></pre>
<p><a href=".">Form</a></p>
</body>
</html>
