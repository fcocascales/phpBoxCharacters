<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>BoxCharacters</title>
<style media="screen">
	body { background-color:#fafafa; }
	fieldset { background-color:#f6f6f6; }
	fieldset p { color:#666; }
	textarea { width:60em; height:20em; }
	legend { font-variant:small-caps;}
	label span { color:#000; }
	button { display:block; padding:1em 2em; }
	code { font-family:monospace; }
	#styles, #layouts { overflow:hidden; }
	.style, .layout { float:left; white-space:pre; font-family:monospace; margin:0 0.5em;}
	fieldset { display:inline-block; vertical-align:top; }
	#separator { width:2em; }
</style>
</head>
<body>
<h1>BoxCharacters</h1>
<form action="result.php" method="post">

<fieldset id="styles">
<legend>Styles</legend>
<div class="style">
┌──┬──┐
│  │  │
├──┼──┤
│  │  │
└──┴──┘
<input type="radio" name="style" value="0" title="fine"></div>
<div class="style">
┏━━┳━━┓
┃  ┃  ┃
┣━━╋━━┫
┃  ┃  ┃
┗━━┻━━┛
<input type="radio" name="style" value="1" title="thick"></div>
<div class="style">
┍━━┯━━┑
│  │  │
┝━━┿━━┥
│  │  │
┕━━┷━━┙
<input type="radio" name="style" value="2" title="thick fine"></div>
<div class="style">
┎──┰──┒
┃  ┃  ┃
┠──╂──┨
┃  ┃  ┃
┖──┸──┚
<input type="radio" name="style" value="3" title="fine thick"></div>
<div class="style">
╔══╦══╗
║  ║  ║
╠══╬══╣
║  ║  ║
╚══╩══╝
<input type="radio" name="style" value="4" title="double"></div>
<div class="style">
╒══╤══╕
│  │  │
╞══╪══╡
│  │  │
╘══╧══╛
<input type="radio" name="style" value="5" title="double fine"></div>
<div class="style">
╓──╥──╖
║  ║  ║
╟──╫──╢
║  ║  ║
╙──╨──╜
<input type="radio" name="style" value="6" title="fine double"></div>
<?php /*<div class="style">
   │
   │
───┼───
   │
   │
<input type="radio" name="style" value="7" title="cross"></div>*/ ?>
</fieldset>

<fieldset id="layouts">
<legend>Layouts</legend>
<div class="layout">
┌──┬──┬──┐
├──┼──┼──┤
├──┼──┼──┤
└──┴──┴──┘
<input type="radio" name="layout" value="0" title="grid"></div>
<div class="layout">
┌──┬──┬──┐
│  │  │  │
│  │  │  │
└──┴──┴──┘
<input type="radio" name="layout" value="1" title="columns"></div>
<div class="layout">
┌────────┐
├────────┤
├────────┤
└────────┘
<input type="radio" name="layout" value="2" title="rows"></div>
<div class="layout">
┌────────┐
│        │
│        │
└────────┘
<input type="radio" name="layout" value="3" title="box"></div>
<div class="layout">
   │  │
───┼──┼───
───┼──┼───
   │  │
<input type="radio" name="layout" value="4" title="cross"></div>
</fieldset>

<fieldset id="options">
<legend>Options</legend>
<p>
	<label for="padding">Padding <span id="range_value">1</span>:</label>
	<input type="range" min="0" max="10" step="1" value="1" name="padding" id="padding"
		onchange="document.getElementById('range_value').innerText = this.value;">
</p>
<p>
	<label for="separator">Cell separator:</label>
	<input type="text" value=";" name="separator" id="separator" maxlength="1">
</p>
</fieldset>

<fieldset>
<legend>Input</legend>
<p>Enter tabular data separated by ; and by line breaks</p>
<textarea name="input">Lorem ipsum; Dolor sit amet; Consectetur; Adipisicing elit
Sed do eiusmod tempor; ; Ut labore et; Dolore magna aliqua.
Ut enim; Ad minim veniam; Quis nostrud; Exercitation ullamco
Laboris nisi; Ut aliquip; ; Commodo consequat
Duis aute irure; Dolor in; Reprehenderit
Esse cillum; Dolore eu; Fugiat nulla; Pariatur
Excepteur
Sunt in culpa; Qui officia deserunt; Mollit anim; Id est laborum</textarea>
</fieldset>

<button>Send</button>
</form>
<?php /*
	$t = "┏┳┓";
	//mb_internal_encoding("UTF-8");
	echo $t;
	//echo $t[0];
	echo mb_substr($t,0,1);
*/ ?>
</body>
</html>
