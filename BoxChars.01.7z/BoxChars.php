<?php
	/*
		┌──┬──┐
		│  │  │
		├──┼──┤
		│  │  │
		└──┴──┘
		┏━━┳━━┓   ┍━━┯━━┑   ┎──┰──┒
		┃  ┃  ┃   │  │  │   ┃  ┃  ┃
		┣━━╋━━┫   ┝━━┿━━┥   ┠──╂──┨
		┃  ┃  ┃   │  │  │   ┃  ┃  ┃
		┗━━┻━━┛   ┕━━┷━━┙   ┖──┸──┚
    ╔══╦══╗   ╒══╤══╕   ╓──╥──╖
    ║  ║  ║   │  │  │   ║  ║  ║
    ╠══╬══╣   ╞══╪══╡   ╟──╫──╢
    ║  ║  ║   │  │  │   ║  ║  ║
    ╚══╩══╝   ╘══╧══╛   ╙──╨──╜
	*/

	class BoxChars {

		const BOX = array(
			"┌┬┐". // style0=fine
			"├┼┤".
			"└┴┘"."─│",
			"┏┳┓". // style1=thick
			"┣╋┫".
			"┗┻┛"."━┃",
			"┍┯┑". // style2=fine thick
			"┝┿┥".
			"┕┷┙"."━│",
			"┎┰┒". // style3=thick fine
			"┠╂┨".
			"┖┸┚"."─┃",
			"╔╦╗". // style4=double
			"╠╬╣".
			"╚╩╝"."═║",
			"╒╤╕". // style5=double fine
			"╞╪╡".
			"╘╧╛"."═│",
	 		"╓╥╖". // style6=fine double
			"╟╫╢".
			"╙╨╜"."─║",
		);

		const TOP_LEFT = 0;
		const BEGIN_VERT = 1;
		const TOP_RIGHT = 2;
		const BEGIN_HORIZ = 3;
		const CROSS = 4;
		const END_HORIZ = 5;
		const BOTTOM_LEFT = 6;
		const END_VERT = 7;
		const BOTTOM_RIGHT = 8;
		const HORIZONTAL = 9;
		const VERTICAL = 10;

		const LAYOUT_GRID = 0;
		const LAYOUT_VERT_HEADER = 1;
		const LAYOUT_HORIZ_HEADER = 2;
		const LAYOUT_VERTICAL = 3;
		const LAYOUT_HORIZONTAL = 4;
		const LAYOUT_BOX = 5;

		private $text;
		private $style;
		private $layout;
		private $widths;

		public function __construct($text="", $style=0, $layout=0) {
			$this->setText($text);
			$this->setStyle($style);
			$this->setLayout($layout);
			$this->widths = array();
		}

		// TEST

		// SETTERS

		public function setText($value) {
			$this->text = $value;
		}
		public function setStyle($value) {
			$value = intval($value);
			if ($value >= 0 && $value < count(self::BOX)) {
				$this->style = $value;
			}
		}
		public function setLayout($value) {
			$value = intval($value);
			if ($value >= 0 && $value <= 5) {
				$this->layout = $value;
			}
		}

		// GETTERS

		public function getText() {
			return $this->text;
		}
		public function getStyle() {
			return $this->style;
		}

		// RESULT

		public function draw() {
			$table = $this->tabulate();
			$table = $this->normalize($table);
			$text = $this->top_line();
			foreach($table as $r=>$row) {
				$text .= $this->box(self::VERTICAL);;
				foreach($row as $c=>$cell) {
					$text .= $cell;
					$spaces = $this->widths[$c] - mb_strlen($cell);
					if ($spaces > 0) $text .= str_repeat(" ", $spaces);
					$isFirstCell = $c == 0;
					$isLastCell = $c == count($row)-1;
					$text .= $this->get_vertical($isFirstCell, $isLastCell);
				}
				$text .= "\n";
				if ($r < count($table)-1)
					$text .= $this->medium_line($r);
				else
					$text .= $this->bottom_line();
			}
			return $text;
		}

		private function get_vertical($isFirstCell, $isLastCell) {
			if ($isLastCell) return $this->box(self::VERTICAL);
			elseif ($this->layout == self::LAYOUT_HORIZ_HEADER
				&& !$isFirstCell) return " ";
			elseif ($this->layout == self::LAYOUT_HORIZONTAL
				|| $this->layout == self::LAYOUT_BOX) return " ";
			else return $this->box(self::VERTICAL);
		}

		// PRIVATE

		/*
			Convert text in array (rows) of arrays (cells)
			and calculate maximum width of each cell
		*/
		public function tabulate() {
			$table = explode("\n", $this->text);
			$this->widths = array();
			foreach($table as &$row) {
				$row = explode(";", $row);
				foreach($row as $c=>&$cell) {
					$cell = trim($cell);

					$length = mb_strlen($cell);
					if (!isset($this->widths[$c]))
						$this->widths[$c] = $length;
					elseif ($length > $this->widths[$c])
						$this->widths[$c] = $length;
				}
			}
			return $table;
		}

		/*
			Same number of cells on each row
		*/
		private function normalize($table) {
			$cols = count($this->widths);
			foreach($table as $r=>&$row) {
				$count = $cols - count($row);
				for ($i=0; $i<$count; ++$i) {
					$row[] = "";
				}
			}
			return $table;
		}


		private function top_line() {
			return $this->line(
				$this->box(self::TOP_LEFT),
				$this->box(self::BEGIN_VERT),
				$this->box(self::TOP_RIGHT),
				$this->box(self::HORIZONTAL)
			);
		}
		private function medium_line($row) {
			switch ($this->layout) {
				case self::LAYOUT_VERT_HEADER: if ($row > 0) return ""; else break;
				case self::LAYOUT_VERTICAL: return "";
				case self::LAYOUT_BOX: return "";
			}
			return $this->line(
				$this->box(self::BEGIN_HORIZ),
				$this->box(self::CROSS),
				$this->box(self::END_HORIZ),
				$this->box(self::HORIZONTAL)
			);
		}
		private function bottom_line() {
			return $this->line(
				$this->box(self::BOTTOM_LEFT),
				$this->box(self::END_VERT),
				$this->box(self::BOTTOM_RIGHT),
				$this->box(self::HORIZONTAL)
			);
		}
		private function line($begin, $middle, $end, $repeat) {
			$text = "";
			$count = count($this->widths);
			$text .= $begin;
			if ($this->layout == self::LAYOUT_HORIZONTAL
			 || $this->layout == self::LAYOUT_BOX) $middle = $repeat;
			foreach($this->widths as $width) {
				$text .= str_repeat($repeat, $width);
				if (--$count==0) break;
				$text .= $middle;
				if ($this->layout == self::LAYOUT_HORIZ_HEADER) $middle = $repeat;
			}
			$text .= $end;
			return "$text\n";
		}

		private function box($index) {
			return mb_substr(self::BOX[$this->style], $index, 1);
		}

	}
