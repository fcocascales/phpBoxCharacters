<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>BoxCharacters</title>
<style media="screen">
	body { background-color:#fafafa; }
	textarea { width:60em; height:20em; }
	button { display:block; padding:1em 2em; }
	code { font-family:monospace; }
	#styles, #layouts { overflow:hidden; }
	.style, .layout { float:left; white-space:pre; font-family:monospace; margin:0 0.5em;}
	fieldset { display:inline-block; vertical-align:top; }
</style>
</head>
<body>
<h1>BoxCharacters</h1>
<form action="result.php" method="post">

<fieldset id="styles">
<legend>Styles</legend>
<div class="style">
┌──┬──┐
│  │  │
├──┼──┤
│  │  │
└──┴──┘
<input type="radio" name="style" value="0" title="fine"></div>
<div class="style">
┏━━┳━━┓
┃  ┃  ┃
┣━━╋━━┫
┃  ┃  ┃
┗━━┻━━┛
<input type="radio" name="style" value="1" title="thick"></div>
<div class="style">
┍━━┯━━┑
│  │  │
┝━━┿━━┥
│  │  │
┕━━┷━━┙
<input type="radio" name="style" value="2" title="thick fine"></div>
<div class="style">
┎──┰──┒
┃  ┃  ┃
┠──╂──┨
┃  ┃  ┃
┖──┸──┚
<input type="radio" name="style" value="3" title="fine thick"></div>
<div class="style">
╔══╦══╗
║  ║  ║
╠══╬══╣
║  ║  ║
╚══╩══╝
<input type="radio" name="style" value="4" title="double"></div>
<div class="style">
╒══╤══╕
│  │  │
╞══╪══╡
│  │  │
╘══╧══╛
<input type="radio" name="style" value="5" title="double fine"></div>
<div class="style">
╓──╥──╖
║  ║  ║
╟──╫──╢
║  ║  ║
╙──╨──╜
<input type="radio" name="style" value="6" title="fine double"></div>
</fieldset>

<fieldset id="layouts">
<legend>Layouts</legend>
<div class="layout">
┌──┬──┬──┐
├──┼──┼──┤
├──┼──┼──┤
└──┴──┴──┘
<input type="radio" name="layout" value="0" title="grid"></div>
<div class="layout">
┌──┬──┬──┐
├──┼──┼──┤
│  │  │  │
└──┴──┴──┘
<input type="radio" name="layout" value="1" title="vert header"></div>
<div class="layout">
┌──┬─────┐
├──┼─────┤
├──┼─────┤
└──┴─────┘
<input type="radio" name="layout" value="2" title="horiz header"></div>
<div class="layout">
┌──┬──┬──┐
│  │  │  │
│  │  │  │
└──┴──┴──┘
<input type="radio" name="layout" value="3" title="vertical"></div>
<div class="layout">
┌────────┐
├────────┤
├────────┤
└────────┘
<input type="radio" name="layout" value="4" title="horizontal"></div>
<div class="layout">
┌────────┐
│        │
│        │
└────────┘
<input type="radio" name="layout" value="5" title="box"></div>
</fieldset>

<fieldset>
<legend>Input</legend>
<p>Introduce datos tabulares separados por ; y por saltos de línea.</p>
<textarea name="input">Lorem ipsum; Dolor sit amet; Consectetur; Adipisicing elit
Sed do eiusmod tempor; ; Ut labore et; Dolore magna aliqua.
Ut enim; Ad minim veniam; Quis nostrud; Exercitation ullamco
Laboris nisi; Ut aliquip; ; Commodo consequat
Duis aute irure; Dolor in; Reprehenderit
Esse cillum; Dolore eu; Fugiat nulla; Pariatur
Excepteur
Sunt in culpa; Qui officia deserunt; Mollit anim; Id est laborum</textarea>
</fieldset>

<button>Send</button>
</form>
<?php /*
	$t = "┏┳┓";
	//mb_internal_encoding("UTF-8");
	echo $t;
	//echo $t[0];
	echo mb_substr($t,0,1);
*/ ?>
</body>
</html>
