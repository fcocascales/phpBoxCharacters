<?php

	$text = isset($_POST['input'])? $_POST['input']: '';
	$text = strip_tags($text);

	$style = isset($_POST['style'])? $_POST['style']: '';
	$style = intval($style);

	$layout = isset($_POST['layout'])? $_POST['layout']: '';
	$layout = intval($layout);

	require_once "BoxChars.php";
	$box = new BoxChars();
	$box->setText($text);
	$box->setStyle($style);
	$box->setLayout($layout);

?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Result</title>
</head>
<body>
<h1>Result</h1>
<p>style=<?php echo $style; ?> layout=<?php echo $layout ?></p>
<pre><code><?php
	//print_r($box);
	//var_dump($box->tabulate());
	echo $box->draw();
?><code></pre>
</body>
</html>
